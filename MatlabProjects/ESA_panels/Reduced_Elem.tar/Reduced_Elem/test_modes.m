% Test modes
clear all
close all
clc

rho = 2000; %M_SA/(l1*l2*3*t); % kg/m^3
E = 70*10^9; % Pa
ni = 0.35; 
xi = 0.01;
lx = 1; %m
ly= 1; %m
t=0.003; %m

P_xy = [0, ly/4];
C_xy = [lx, ly/4; ...
        lx, 3*ly/4];

MFzTxTy = Kirchhoff_1elem_modal(lx, ly, t, rho, E, ni, xi, P_xy, C_xy, 1);

