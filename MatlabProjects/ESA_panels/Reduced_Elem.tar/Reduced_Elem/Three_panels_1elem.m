% Equivalent Matlab script to the Simulink model
clear all
close all
clc
M_SA = 1100;
Jzz_SA = 212;

lx=1; ly=1;

lx_1=lx; %m
ly_1=ly; %m
lx_2=lx; %m
ly_2=ly; %m
lx_3=lx; %m
ly_3=ly; %m
t=0.003; %m
rho = M_SA/(t*(lx_1*ly_1+lx_2*ly_2+lx_3*ly_3)); % kg/m^3
E = 70*10^9; % Pa
ni = 0.35; 
xi = 0.01; xi_1 = xi; xi_2 = xi; xi_3 = xi;


P_xy_1 = [0, ly/4];
P_xy_2 = [0, ly/4];
P_xy_3 = [0, ly/4];

C_xy_1 = [lx, ly/4;
          lx, 3*ly/4];
      
C_xy_2 = [0,  3*ly/4;
          lx, ly/4;
          lx, 3*ly/4];
      
C_xy_3 = [0, 3*ly/4];

ind_1 = 0;
ind_2 = [1:3];
ind_3 = [1:3];


[A_sim,B_sim,C_sim,D_sim] = linmod('Sentinel_model_1elem_modal');
sys_Simu = ss(A_sim,B_sim,C_sim,D_sim);
sys_Simu_red = minreal(sys_Simu, 10^-8);
Masses = dcgain(sys_Simu_red);
lambda_S = eig(sys_Simu_red.a);

figure(3)
plot(real(lambda_S),imag(lambda_S),'bo')
hold on 
plot([0 0],[min([imag(lambda_S)]) max([imag(lambda_S)]) ],'g')
legend('Simulink','Imag Axis')