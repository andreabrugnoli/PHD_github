% Boite � outils DESOUTILS
% Version 2.0a   10-Novembre-02    
%   
% Gestion des graphiques.
%   paysage    - Mise au format A4 (mode paysage) de la figure courante.
%   portrait   - Mise au format A4 (mode portrait) de la figure courante.
% 
% Conversion de format.
%   pck2ss     - Conversion des syst�mes du format PCK au format SS.
%   ss2pck     - Conversion des syst�mes du format SS au format PCK.
%   test_natss - Genere les matrices a, b, c, d d'un systeme, SSobject ou Pack
%
% Analyse graphique des syst�mes.
%   black      - Lieu de Black g�n�ral.
%   rlocusp    - Lieux des racines points par points.
%   rsqlocus   - Lieux du carr� des racines.
%   rsqlocustd - Lieux des carr�s des racines d'une forme standard continue.
%   clickmap   - reduction interactive de syst�me et/ou correcteur
%
